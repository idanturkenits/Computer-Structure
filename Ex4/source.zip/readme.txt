How To Compile:
	no optimizations = gcc code.c -o MyEx
	with O1 optimizations = gcc -O1 code.c -o MyEx
	with O2 optimizations = gcc -O2 code.c -o MyEx
	with O3 optimizations = gcc -O3 code.c -o MyEx
	










